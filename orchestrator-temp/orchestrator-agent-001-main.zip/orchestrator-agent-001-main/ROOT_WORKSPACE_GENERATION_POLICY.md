# ROOT_WORKSPACE_GENERATION_POLICY.md

This file defines where generated orchestrator artifacts must be placed.

It does not replace `AGENTS.md`. The canonical orchestrator behavior is always defined in `AGENTS.md`.

## Clean project onset rule

At the start of a project, do not pre-create every orchestrator folder.

Keep only the main instruction/config files. The orchestrator should create operational folders during bootstrap or when a task requires them.

## Do not write generated operational artifacts inside

- `schemas/`
- `examples/`
- `.git/`
- `node_modules/`
- `.venv/`
- `venv/`
- `dist/`
- `build/`
- `.next/`
- unrelated application folders unless the user explicitly targets them

## On-demand root folders

The orchestrator may create these folders when bootstrap or task execution requires them:

```text
agents/
workflows/
tasks/
runtime/
registry/
graph/
topology/
deliverables/
human-review/
observability/
docs/
configs/
tests/
scripts/
integrations/
memory/
agentic-system/
database/
```

## Placement map

| Artifact type | Required root folder |
|---|---|
| Generated agent instructions | `agents/generated/` |
| Custom human agents | `agents/custom/` |
| Human controller agents | `agents/human/` |
| Archived agents | `agents/archived/` |
| Workflow manifests | `workflows/` |
| Task breakdowns | `tasks/` |
| Agent registry | `registry/agents/` |
| Workflow registry | `registry/workflows/` |
| Vector registry | `registry/vector/` |
| Neo4j schema, constraints, seed, migrations | `graph/neo4j/` |
| Workspace graph JSON | `graph/` |
| D3 graph data | `topology/d3/` |
| Execution topology | `topology/execution/` |
| Infrastructure topology | `topology/infrastructure/` |
| API/data topology | `topology/api/`, `topology/data/` |
| Standalone D3 Agentic System page | `agentic-system/d3/` |
| Runtime graph services | `runtime/graph/` |
| Runtime vector services | `runtime/vector/` |
| Runtime agent-memory services | `runtime/agent-memory/` |
| Vector provider resolution | `memory/vector/` |
| Prompt ledger | `memory/vector/prompt-ledger.jsonl` |
| Redacted prompt summaries | `memory/agent-knowledge/prompts/` |
| Agent knowledge summaries | `memory/agent-knowledge/agents/` |
| Project knowledge summaries | `memory/agent-knowledge/projects/` |
| Pending memory sync | `memory/pending-sync/` |
| Neo4j sync logs | `observability/graph/` |
| Vector memory logs | `observability/vector-memory/` |
| Agent memory logs | `observability/agent-memory/` |
| Delivery manifests | `deliverables/` |
| Validation reports | `deliverables/validation/` |
| Human review requests | `human-review/requests/` |
| Human decisions | `human-review/decisions/` |
| Documentation | `docs/` |
| Scripts | `scripts/` |
| Configs | `configs/` |
| Database schemas/migrations | `database/` |
| Tests | `tests/` |
| Integrations | `integrations/` |

## Bootstrap behavior

When the user asks to bootstrap, initialize, verify, or repair orchestrator memory, the orchestrator may create the full operational scaffold required by `AGENTS.md`.

Before bootstrap, this package intentionally contains only instruction/config files.

## ChromaDB fallback placement

If no vector DB is configured in `.env`, generate ChromaDB fallback files on demand in the root-level locations required by `AGENTS.md`, such as:

```text
docker-compose.chroma.yml
configs/chromadb.config.json
runtime/vector/chromadb.service.ts
scripts/init-chromadb.ts
scripts/sync-agent-knowledge-to-chromadb.ts
scripts/verify-chromadb.ts
memory/vector/chroma-collections.json
observability/vector-memory/chromadb-verification.json
```
