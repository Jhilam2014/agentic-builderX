Read AGENTS.md, ROOT_WORKSPACE_GENERATION_POLICY.md, and qagentic-support/README.md fully.

Enable orchestrator-agent mode with QAgentic support.

Bootstrap the mandatory orchestrator infrastructure for this project.

Preserve all existing features and files unless a required bootstrap artifact is missing.

Create or verify QAgentic baseline artifacts:

1. qagentic-support/qagent-framework.md
2. qagentic-support/qagent-controller.md
3. qagentic-support/qagent-stop-rules.md
4. qagentic-support/runtime-qagent-template.md
5. qagentic-support/qagent-memory-policy.md
6. schemas/qagent-next-instruction.schema.json
7. .codex/prompts/task-qagentic.md
8. observability/qagentic/latest-qagentic-bootstrap.json

Rules:
- Base QAgent framework is generated at project onset.
- Runtime QAgents are generated only when objective gaps are detected.
- QAgents produce Next Instruction Packets; they do not directly implement code.
- Use existing agents before creating runtime QAgents.
- Respect stop rules and iteration caps.
- Do not remove, weaken, or bypass existing graph, vector, D3, memory, Neo4j, ChromaDB, validation, or token-economy behavior.

After bootstrap, report QAgentic artifacts created or verified, validation status, and pending configuration.
