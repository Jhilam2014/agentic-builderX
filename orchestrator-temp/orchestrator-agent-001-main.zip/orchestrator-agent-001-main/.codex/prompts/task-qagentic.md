Read AGENTS.md and qagentic-support/README.md fully.

Enable QAgentic continuation mode for this task.

Task type: tiny | small | medium | large
Task: <write your task here>

Execution rules:
- Preserve existing features.
- Reuse existing project agents before creating runtime QAgents.
- Make the narrowest complete change.
- Validate in proportion to risk.
- At the end of the response, run the QAgent Controller mentally or through the available local QAgentic files.
- If the objective is incomplete, emit a Next Instruction Packet using schemas/qagent-next-instruction.schema.json.
- If the objective is complete, explicitly stop QAgent continuation and summarize why.

Stop rules:
- Stop if validation passes and the original objective is complete.
- Stop if remaining items are only polish or speculative.
- Stop at the iteration cap for the task type.
- Ask the Human Controller only for destructive, credential, production, or materially ambiguous choices.

After completion, report:
- files modified
- validation result
- QAgentic stop/continue decision
- next instruction packet path if one was generated
- memory/vector/graph/D3 update status
