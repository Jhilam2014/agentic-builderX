# Orchestrator Agent Support Files

Generated at: 2026-06-23T07:54:19.692369+00:00

This package keeps your uploaded orchestrator instruction unchanged.

## Important

`AGENTS.md` is copied exactly from the uploaded orchestrator instruction.

SHA256 of canonical AGENTS.md:

```text
8de8868fe788e48fbafb4b9a9964f1d3bbe9d5e1906847583dfbdb942c2055ca
```

Do not modify `AGENTS.md` unless you explicitly want to change the canonical orchestrator-agent instruction.

## Included files

```text
AGENTS.md
CLAUDE.md
ROOT_WORKSPACE_GENERATION_POLICY.md
.env.example
README.md
docs/USAGE.md

.codex/prompts/
├── bootstrap-orchestrator.md
├── task-router.md
├── task-small.md
├── task-medium.md
└── task-large.md

.claude/
└── settings.example.json
```

## Not included

This package does not pre-create runtime folders like:

```text
agents/
graph/
memory/
topology/
agentic-system/
runtime/
registry/
observability/
```

Those should be created during bootstrap or task execution according to `AGENTS.md`.

## First command

```text
Use .codex/prompts/bootstrap-orchestrator.md and execute the bootstrap.
```

## Daily command

```text
Task type: small
Task: <your task>
```
